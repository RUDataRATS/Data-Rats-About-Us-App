package datarats.aboutusrats;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ExtrasActivity extends Activity {

    Intent backAbout;



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_extras);

       backAbout = new Intent(ExtrasActivity.this, AboutActivity.class);
        final Button button = (Button) findViewById(R.id.backAbout);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(backAbout);
            }
        });
    }
}
