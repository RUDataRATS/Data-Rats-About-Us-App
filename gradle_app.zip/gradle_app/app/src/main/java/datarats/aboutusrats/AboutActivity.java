package datarats.aboutusrats;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class AboutActivity extends Activity {


    Intent HomeScreen;
    Intent ExtrasScreen;
    Intent AboutJames;

    public AboutActivity(){


    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        HomeScreen = new Intent(AboutActivity.this, HomeScreen.class);
        ExtrasScreen = new Intent(AboutActivity.this, ExtrasActivity.class);
        AboutJames = new Intent(AboutActivity.this, AboutJames.class);

        final Button extrasButton = (Button) findViewById(R.id.extrasButton);
        extrasButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(ExtrasScreen);
            }
        });

        final Button backButton = (Button) findViewById(R.id.backMain);
        backButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(HomeScreen);
            }
        });

        final Button jamesButton = (Button) findViewById(R.id.jamesButton);
        jamesButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(AboutJames);
            }
        });
    }
}
